/**
 * File Name: GRBglobal
 *
 * Revision History:
 *       Gloria Rivas-Bonilla, 4/01/2023 : Created
 */



//ready function
function init(){

}


//ready event
$(document).ready(function () {
    init();
});